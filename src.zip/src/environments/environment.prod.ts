export const environment = {
  Enablecrypto: false,
  EncvKey: "8080808080808080",
  SHAHash: "86173adafb979cf6a476cef68871e658f675152ac7b73c1aff098b87a602a9a9",
  production: true
};
